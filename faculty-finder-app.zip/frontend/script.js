function searchFaculty() {
  const query = document.getElementById('searchInput').value;
  fetch(`http://localhost:3000/api/search?q=${query}`)
    .then(res => res.json())
    .then(data => {
      const results = document.getElementById('results');
      results.innerHTML = '';
      data.forEach(faculty => {
        results.innerHTML += `
          <div class="card">
            <img src="http://localhost:3000/uploads/${faculty.profile_picture}" alt="${faculty.name}">
            <div>
              <h3>${faculty.name}</h3>
              <p>Dept: ${faculty.department}</p>
              <p>Cabin: ${faculty.cabin}</p>
              <p>Room: ${faculty.room_number}</p>
            </div>
          </div>
        `;
      });
    });
}