const mysql = require('mysql2');
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'faculty_finder'
});
db.connect((err) => {
  if (err) throw err;
  console.log('MySQL connected');
});
module.exports = db;