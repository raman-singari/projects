const express = require('express');
const router = express.Router();
const db = require('./db');

router.get('/search', (req, res) => {
  const { q } = req.query;
  const sql = `SELECT * FROM faculty WHERE name LIKE ? OR room_number LIKE ?`;
  db.query(sql, [`%${q}%`, `%${q}%`], (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

module.exports = router;